d<-c(1,0,2,0,1,0,0,0,2,1,0,0,1,0,1,0,0,0,1,0,0,0,1,0,0,0,0,0,0,0,0,0,1,0,0,0,0)
r<-c(0,1,0,1,0,1,5,3,0,0,1,4,0,1,0,2,4,4,0,4,3,3,0,1,2,1,1,2,2,1,3,2,0,1,1,3,1)

d<-c(1,0,0,0,1,0,0,0,0,0,0,0,1,0,1,0,0,0,1,1,0,0,0,0,0,0,1,0,0,0,1,1,0,1,0,1,0,0)
r<-c(0,1,1,1,0,1,1,1,1,1,1,1,0,1,0,1,1,1,0,0,1,1,1,1,1,1,0,1,1,1,0,0,1,0,1,0,1,1)
t<-c(6700,6950,7820,8790,9120,9660,9820,11310,11690,11850,11880,12140,12200,12870,13150,13330,13470,14040,14300,17520,17540,17890,18450,18960,18980,19410,20100,20100,20150,20320,20900,22700,23490,26510,27410,27490,27890,28100)
length(r)

d<-c(1,1,1,1,1,1,1,1,2)

plot(c(0,t[1]-1),c(0,0),type = "l",ylim = c(0,1),xlim = c(0,28100),main = "Estimaci�n no param�trica hasta 28100 km",xlab = "Kilometros",ylab = "Proporci�n de falla")

lines(c(t[1],t[5]-1),c(f[1],f[1]))
lines(c(t[1],t[5]-1),c(fu[1],fu[1]),type = "c",lty=2)
lines(c(t[1],t[5]-1),c(ft[1],ft[1]),type = "c",lty=2)

lines(c(t[5],t[13]-1),c(f[5],f[5]))
lines(c(t[5],t[13]-1),c(fu[5],fu[5]),type = "c",lty=2)
lines(c(t[5],t[13]-1),c(ft[5],ft[5]),type = "c",lty=2)

lines(c(t[13],t[15]-1),c(f[13],f[13]))
lines(c(t[13],t[15]-1),c(fu[13],fu[13]),type = "c",lty=2)
lines(c(t[13],t[15]-1),c(ft[13],ft[13]),type = "c",lty=2)

lines(c(t[15],t[19]-1),c(f[15],f[15]))
lines(c(t[15],t[19]-1),c(fu[15],fu[15]),type = "c",lty=2)
lines(c(t[15],t[19]-1),c(ft[15],ft[15]),type = "c",lty=2)

lines(c(t[19],t[20]-1),c(f[19],f[19]))
lines(c(t[19],t[20]-1),c(fu[19],fu[19]),type = "c",lty=2)
lines(c(t[19],t[20]-1),c(ft[19],ft[19]),type = "c",lty=2)

lines(c(t[20],t[27]-1),c(f[20],f[20]))
lines(c(t[20],t[27]-1),c(fu[20],fu[20]),type = "c",lty=2)
lines(c(t[20],t[27]-1),c(ft[20],ft[20]),type = "c",lty=2)

lines(c(t[27],t[31]-1),c(f[27],f[27]))
lines(c(t[27],t[31]-1),c(fu[27],fu[27]),type = "c",lty=2)
lines(c(t[27],t[31]-1),c(ft[27],ft[27]),type = "c",lty=2)

lines(c(t[31],t[32]-1),c(f[31],f[31]))
lines(c(t[31],t[32]-1),c(fu[31],fu[31]),type = "c",lty=2)
lines(c(t[31],t[32]-1),c(ft[31],ft[31]),type = "c",lty=2)

lines(c(t[32],t[34]-1),c(f[32],f[32]))
lines(c(t[32],t[34]-1),c(fu[32],fu[32]),type = "c",lty=2)
lines(c(t[32],t[34]-1),c(ft[32],ft[32]),type = "c",lty=2)

lines(c(t[34],t[36]-1),c(f[34],f[34]))
lines(c(t[34],t[36]-1),c(fu[34],fu[34]),type = "c",lty=2)
lines(c(t[34],t[36]-1),c(ft[34],ft[34]),type = "c",lty=2)

lines(c(t[36],t[38]),c(f[36],f[36]))
lines(c(t[36],t[38]),c(fu[36],fu[36]),type = "c",lty=2)
lines(c(t[36],t[38]),c(ft[36],ft[36]),type = "c",lty=2)

n<-c(38)

p<-c()

p1<-c()

S<-c()

fu<-c()

ft<-c()



for (i in 1:9) {
  fu[i]<-sum(d[1:i])/130+qnorm(1-0.1/2)*sqrt(sum(d[1:i])/130*(1-sum(d[1:i])/130)/130)
  ft[i]<-sum(d[1:i])/130-qnorm(1-0.1/2)*sqrt(sum(d[1:i])/130*(1-sum(d[1:i])/130)/130)
}

for (i in 2:38) {
  
  n[i]<-38-sum(d[1:(i-1)])-sum(r[1:(i-1)])
  
  p[i-1]<-d[i-1]/n[i-1]
  
  p1[i-1]<-1-p[i-1]
  
  S[i-1]<-prod(p1[1:(i-1)])
  
}

length(S)

f<-1-S

se<-c()

for (i in 1:38) {
  se[i]<-sqrt((S[i])^2*sum(p[1:i]/(n[1:i]*(1-p[1:i]))))
}
se

fu<-c()
ft<-c()

for (i in 1:38) {
  w<-exp(qnorm(1-0.1/2)*se[i]/(f[i]*(1-f[i])))
  fu[i]<-f[i]/(f[i]+(1-f[i])*w)
  ft[i]<-f[i]/(f[i]+(1-f[i])/w)
}

conf<-matrix(NA,nrow = 38,ncol = 2)
conf[,1]<-fu
conf[,2]<-ft


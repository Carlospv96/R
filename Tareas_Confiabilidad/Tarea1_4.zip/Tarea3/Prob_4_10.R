F<-function(t,s,m){ return(1-exp(-exp((t-m)/s))) }

F(0,5,50)

F(0,6,50)

F(0,7,50)

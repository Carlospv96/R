#####GR�FICA wEIBULL

###FDP

w<-function(x,b,n){(b/n)*(x/n)^(b-1)*exp(-(x/n)^b)}

par(mfrow=c(2,2))

### n=50

curve(w(x,0.5,50),col='coral3',xlab = 't', ylab = 'f(t)' ,main = expression(paste("fdp Weibull con ",eta,"=50 y ",beta,"=0.5")))

curve(w(x,1,50),col='royalblue2',xlab = 't', ylab = 'f(t)' ,main = expression(paste("fdp Weibull con ",eta,"=50 y ",beta,"=1")))

curve(w(x,3,50),col='mediumpurple2',xlab = 't', ylab = 'f(t)' ,main = expression(paste("fdp Weibull con ",eta,"=50 y ",beta,"=3")))

curve(w(x,5,50),col='mediumspringgreen',xlab = 't', ylab = 'f(t)' ,main = expression(paste("fdp Weibull con ",eta,"=50 y ",beta,"=5")))

### n=100

curve(w(x,0.5,100),col='coral3',xlab = 't', ylab = 'f(t)' ,main = expression(paste("fdp Weibull con ",eta,"=100 y ",beta,"=0.5")))

curve(w(x,1,100),col='royalblue2',xlab = 't', ylab = 'f(t)' ,main = expression(paste("fdp Weibull con ",eta,"=100 y ",beta,"=1")))

curve(w(x,3,100),col='mediumpurple2',xlab = 't', ylab = 'f(t)' ,main = expression(paste("fdp Weibull con ",eta,"=100 y ",beta,"=3")))

curve(w(x,5,100),col='mediumspringgreen',xlab = 't', ylab = 'f(t)' ,main = expression(paste("fdp Weibull con ",eta,"=100 y ",beta,"=5")))

skw<-function(b) { (gamma(1+3/b)-gamma(1+1/b)*(3*gamma(1+2/b)-2*gamma(1+1/b)^2))/(gamma(1+2/b)-gamma(1+1/b)^2)^(3/2) }

skw(0.5)

skw(1)

skw(3)

skw(5)
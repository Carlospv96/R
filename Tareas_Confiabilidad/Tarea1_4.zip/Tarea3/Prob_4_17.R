x<-runif(500,0,1)

t<-c()

t<-qlnorm(x,5,0.8)

par(mfrow=c(1,2))

hist(t,col = "royalblue2",main = "Histogram de T")

curve(dlnorm(x,5,0.8),0,2000,xlab='t',ylab = "f(t)",col="mediumpurple2", main="Gr�fica de la funci�n de densidad")

median(t)

qlnorm(0.5,5,0.8)

mean(t)

exp(5+0.5*0.8^2)

sd(t)

sqrt(exp(2*5+0.8^2)*(exp(0.8^2)-1))


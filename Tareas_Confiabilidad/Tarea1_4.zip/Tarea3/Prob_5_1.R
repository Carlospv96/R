hr<-function(t,t2){(0.5*exp(-t)+0.1*exp(-t/t2))/(0.5*(exp(-t)+exp(-t/t2)))}

curve(hr(x,5),0,10,main="Gr�fica de la funci�n de Riesgo",xlab = "t", ylab = "h(t)",col="mediumpurple3")

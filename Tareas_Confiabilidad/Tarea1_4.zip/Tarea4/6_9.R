#Function for constructing probability plots for
#interval and arbitrarily censored data
t1=c(2000,2500,3000,3500,3600,3700)
t2=c(2500,3000,3500,3600,3700,3800)


ProbPlotInterval(time=t1,time2 = t2,c(3,3,3,3,3,3),weight=c(1,1,2,1,1,1),
                 dis="exponential",shape=NULL, simplify=TRUE)
ProbPlotInterval(time=t1,time2 = t2,c(3,3,3,3,3,3),weight=c(1,1,2,1,1,1),
                 dis="lognormal",shape=NULL, simplify=TRUE)
ProbPlotInterval(time=t1, time2=t2, event=c(3,3,3,3,3,3),weight=c(1,1,2,1,1,1),
                 dist="weibull",shape=NULL, simplify=TRUE)

ProbPlotInterval <- function (time, time2=rep(NA, length(time)), event,
                              weight=rep(1, length(time)), dist,
                              shape=NULL, simplify=TRUE){
  #-time is the right/left censored value, the exact lifetime observation, or for
  # interval censoring the lower value of the censoring interval.
  #-time2 is the upper value of the censoring interval.
  #-event is the censoring indicator (0=right censored, 1=event at time,
  # 2=left censored, 3=interval censored).
  #-weight is an optional vector the weights for the observations
  #-dist is the assumed distribution for the data. Distributions "lognormal",
  # "gaussian", "exponential", "weibull", "sev" (=Gumbel), "frechet",
  # "lev" (=largest extreme value), "logistic" ,"loglogistic", "gamma", and
  # "beta" are implemented.
  #-shape is a vector for specifying the shape parameter(s) of distributions
  # such as the beta and gamma distribution (see Examples 2, 3, and 4 below).
  #-simplify: if TRUE then do not return a matrix containing the data points
  # (=data), standardized quantiles (=standardQuantile), and corresponding
  # probabilities.
  
  #plotting positions
  cumSurvRaw <- survfit(Surv(time=time, time2=time2,
                             event=event, type="interval",origin = 0)~1,
                        weights=weight)
  
  cumSurv <- cumSurvRaw$surv
  cumFail <- 1-cumSurv
  Prob <- cumFail
  
  datai <- time2
  
  #labels for ticks along y-axis
  tick.probs <- c(.001,.005,.01,.02,.05,.1,.2,.3,.4,.5,.6,.7,.8,.9,.99,.999)
  
  #implement distributions
  if (dist=="lognormal" | dist=="gaussian") {
    yi <- qnorm(Prob) #plotting positions
    tick.pos <- qnorm(tick.probs) #positions for ticks along y-axis
    ylimr <- qnorm(range(tick.probs)) #range along y-axis
  }
  else if (dist=="exponential") {
    yi <- qexp(Prob) #plotting positions
    tick.pos <- qexp(tick.probs) #positions for ticks along y-axis
    ylimr <- qexp(range(tick.probs)) #range along y-axis
  }
  else if (dist=="weibull" | dist=="sev") {
    yi <- qsev(Prob) #plotting positions
    tick.pos <- qsev(tick.probs) #positions for ticks along y-axis
    ylimr <- qsev(range(tick.probs)) #range along y-axis
  }
  else if (dist=="frechet" | dist=="lev") {
    yi <- qlev(Prob) #plotting positions
    tick.pos <- qlev(tick.probs) #positions for ticks along y-axis
    ylimr <- qlev(range(tick.probs)) #range along y-axis
  }
  else if (dist=="loglogistic" | dist=="logistic") {
    yi <- qlogis(Prob) #plotting positions
    tick.pos <- qlogis(tick.probs) #positions for ticks along y-axis
    ylimr <- qlogis(range(tick.probs)) #range along y-axis
  }
  else if (dist=="gamma") {
    yi <- qgamma(Prob, shape=shape) #plotting positions
    tick.pos <- qgamma(tick.probs, shape=shape) #positions for ticks along y-axis
    ylimr <- qgamma(range(tick.probs), shape=shape) #range along y-axis
  }
  else if (dist=="beta") {
    yi <- qbeta(Prob, shape1=shape[1], shape2=shape[2]) #plotting positions
    tick.pos <- qbeta(tick.probs, shape1=shape[1], shape2=shape[2]) #positions for ticks along y-axis
    ylimr <- qbeta(range(tick.probs), shape1=shape[1], shape2=shape[2]) #range along y-axis
  }
  
  #determine range along x-axis
  rangeData <- range(cumSurvRaw$time)
  
  #construct plot
  #distributions that require a log transform of the data scale
  if (dist=="weibull" | dist=="lognormal" | dist=="frechet" |
      dist=="loglogistic") {
    plot(0, type="n", log="x",
         xlim=c(rangeData[1], rangeData[2]),
         ylim=c(ylimr[1], ylimr[2]),
         xlab="Horas", ylab="Proporci�n de Falla", main=paste("Distribuci�n",dist),
         axes=FALSE, frame.plot=TRUE)}
  else {
    plot(0, type="n",
         xlim=c(rangeData[1], rangeData[2]),
         ylim=c(ylimr[1], ylimr[2]),
         xlab="Horas", ylab="Proporci�n de falla", main=paste("Distribucion",dist),
         axes=FALSE, frame.plot=TRUE)}
  
  axis(2, at=tick.pos, labels=tick.probs,las=1)
  axis(1,las=2)
  points(datai, yi, col="royalblue", cex = 1)
  #draw raster
  abline(h = tick.pos, lty=3, col="gray")
  abline(v = axTicks(1), lty=3, col="gray")
  
  #return plotting positions
  if (!simplify) cbind(data=datai, standardQuantile=yi, probability=Prob)
  datai
}
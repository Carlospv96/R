t<-c(94,96,99,99,104,108,112,114,117,117,118,121,121,123,129,131,133,135,136
     ,139,139,140,141,141,143,144,149,149,152,153,159,159,159,159,162,168
     ,168,169,170,170,171,172,173,176,177,180,180,184,187,188,189,190,196
     ,197,203,205,211,213,224,226,227,256,257,269,271,274,291)

curve(0*x,0,t[1]-0.1,xlim = c(0,300),ylim=c(0,1))

for (i in 2:length(t)) {
  if(i!=length(t)) {
    curve(i/72 * x/x,t[i-1],t[i]-0.1,add = TRUE)
  }else{
    curve(i/72 * x/x,t[i-1],291,add = TRUE)
  }
}

p<-seq(1,72,by=1)

p<-(p-0.5)/72

plot(log(t),qsev(p)[1:67],xaxt='n',yaxt='n')

axis(1,at=log(t),labels = t,las=2)

axis(2,at=qsev(p),labels = round(p,2),las=1)

plot(log(t),qnorm(p)[1:67],xaxt='n',yaxt='n')

axis(1,at=log(t),labels = t,las=2)

axis(2,at=qsev(p),labels = round(p,2),las=1)

grid()

t<-c(0.74,1.21,0.22,0.37,1.28,0.73,0.99,0.67,0.71,0.33)

p<-c()

for (i in 1:10) {
  p[i]<-(i-0.5)/10
}

p

plot(log(sort(t)),qsev(p),main = "Gr�fica de Probabilidad",xlab = "t",ylab = "p=(i-0.5)/10")

abline(-0.14,0.85)

x<-seq(0,1,by=0.01)
abline(0,0.5)

t<-c(18,32,39,53,59,68,77,78,93)

curve(0*x,0,t[1]-0.1,xlim = c(0,100),ylim=c(0,0.1))
curve(1/100 * x/x,t[1],t[2]-0.1,add = TRUE)
curve(2/100 * x/x,t[2],t[3]-0.1,add = TRUE)
curve(3/100 * x/x,t[3],t[4]-0.1,add = TRUE)
curve(4/100 * x/x,t[4],t[5]-0.1,add = TRUE)
curve(5/100 * x/x,t[5],t[6]-0.1,add = TRUE)
curve(6/100 * x/x,t[6],t[7]-0.1,add = TRUE)
curve(7/100 * x/x,t[7],t[8]-0.1,add = TRUE)
curve(8/100 * x/x,t[8],t[9]-0.1,add = TRUE)
curve(9/100 * x/x,t[9],100,add = TRUE)

points(c(0,t),seq(0,9,by=1)/100,col="royalblue")

t<-c()
d<-seq(1,1,length.out = 9)
n<-c()
p<-c()
s<-c()
f<-c()

for (i in 1:9) {
  
  if (i==1) {
    
    n[i]=100
    p[i]=d[i]/n[i]
    s[i]=prod(1-p)
    f[i]<-1-s[i]
    
  }else{
    
    n[i]=100-sum(d[1:i-1])
    p[i]=d[i]/n[i]
    s[i]=prod(1-p)
    f[i]<-1-s[i]
    
  }
  
}

p1<-c(f[1]/2)

for (i in 2:9) {
  p1[i]<-1/2 * (f[i-1]+f[i])
}

t<-c(18,32,39,53,59,68,77,78,93)

p<-c()

for (i in 1:9) {
  p[i]<-(i-0.5)/100
}

plot(log(t),qsev(p),xaxt='n',yaxt='n',ylim = qsev(c(0.001,0.99)),
     xlab = "Tiempo en miles de horas",
     ylab = "Fracci�n de Falla",col="royalblue",
     main="Gr�fica de Probabilidad")

axis(1,at=log(t),labels = t,las=2)

axis(2,at=qsev(p),labels = p,las=1)

axis(2,at=qsev(seq(0.1,0.95,0.05)),labels = seq(0.1,0.95,0.05),las=1)

abline(lm(qsev(p)~log(t)))

grid()

curve(0*x,0,t[1]-0.1,xlim = c(0,100),ylim=c(0,0.1),
      xlab = "t",ylab = "Proporcion de falla")

for (i in 1:9) {
  if ( i!=9 ) {
    curve(p[i] * x/x,t[i],t[i+1]-0.1,add = TRUE)
  }else{
    curve(p[i] * x/x,t[i],100,add = TRUE)
  }
}

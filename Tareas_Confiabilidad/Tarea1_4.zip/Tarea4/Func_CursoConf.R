##
##  Funciones para el curso de Confiabilidad
##

#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

#....Función para graficar las observaciones
Plot.Observations = function(reliability.data, Ntotal = -999)
{
  # Specify Ntotal if plotting a subset of the data.
  dat = reliability.data
  fail = sort(dat[dat$evento==1,"tiempo"])
  # i.e., if there are censored observations:
  if(sum(dat$evento)<nrow(dat)) {
    cens = sort(dat[dat$evento==0,"tiempo"])
    dat2 = data.frame(fail=fail,cens=NA)
    fail.df = data.frame(fail=NA,cens=cens)
    dat2 = rbind(dat2,fail.df)
    time.index = apply(dat2,1,sum,na.rm=T)
    dat3 = dat2[order(time.index),]
    par(yaxt="n")
    barplot(t(as.matrix(dat3[nrow(dat3):1,])),
            beside=T,horiz=T,col=c("black","red"),border=NA,
            xlab="tiempo") 
    plot.dat = barplot(t(as.matrix(dat3[nrow(dat3):1,])),
                        beside=T,horiz=T,border=NA,plot=F)
    par(yaxt="s")
    N.dataset = ifelse(Ntotal==-999,nrow(dat),Ntotal)
    Start.y = N.dataset - nrow(dat) + 1
    Difference = abs(nrow(dat)-max(c(seq(1,nrow(dat3),by=5))))
    axis(2,at=plot.dat[1,c(seq(1,nrow(dat3),by=5))] + ceiling(plot.dat[2,Difference]),
         labels=rev(seq(Start.y,N.dataset,by=5)),
         las=1,adj=0.5,cex.axis=0.85)
  } else{
    barplot(t(as.matrix(fail[length(fail):1])),col="black",
            horiz=T,border=NA,
            xlab="tiempo")
    plot.dat = barplot(t(as.matrix(fail[length(fail):1])), beside=T,
                        horiz=T,border=NA,plot=F)
    Difference = abs(length(fail)-max(c(seq(1,length(fail),by=5))))
    axis(2,at=plot.dat[seq(1,length(fail),by=5)] +  ceiling(plot.dat[2,Difference]),
         labels=rev(seq(1,length(fail),by=5)),
         las=1,adj=0.5,cex.axis=0.85)
  }
  legend("topright",
         legend=c("Falla","Censura"),
         pch=15,
         col=c("black","red"),
         bty='n',
         horiz=F,xpd=NA,pt.cex=1.5)
  mtext("Observaciones ordenadas",side=2,line=2.5,adj=0.5)
}

#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

##.... Mi función para graficar observaciones

Graf.Observ = function(dat.conf) {
  dat = dat.conf
  n.dat = nrow(x=dat)
  ind.t = n.dat:1; max.t = max(dat$tiempo)
  simb.cens = rep(4, times = n.dat)
  simb.cens[dat$evento==0] = 3 
  col.cens = rep("blue", times = n.dat)
  col.cens[dat$evento==0] = "red"
  plot(x = dat$tiempo, y = ind.t, type = "n", xlim = c(0,max.t), yaxt = "n",
       ylim = c(1,n.dat+1), bty = "l", xlab = "Tiempo", ylab = "Observación" )
  points(x = dat$tiempo, y = ind.t, pch = simb.cens, col = col.cens) 
  axis(2, at = seq(from=1, to=n.dat, by=5), labels = seq(from=n.dat, to=1, by=-5),
       las = 1)
  for( ii in 1:n.dat)
     lines(x = c(0,dat$tiempo[ii]), y = c(ind.t[ii],ind.t[ii]), col = col.cens[ii])
}

#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

#Function for constructing probability plots for
#complete (uncensored) and right censored data
ProbPlot <- function (data, event=rep(1, length(data)),
                      weight=rep(1, length(data)), dist,
                      shape=NULL, simplify=TRUE){
  #-data is a vector containing the observed data points.
  #-event is a status indicator (with possible values 0 and 1) for specifying
  # whether an observation is right censored (=0) or not (=1). This indicator
  # can be omitted in case of complete (uncensored) data.
  #-weight is an optional vector with the weights for the observations.
  #-dist is the assumed distribution for the data. Distributions "lognormal",
  # "gaussian", "exponential", "weibull", "sev" (=Gumbel), "frechet",
  # "lev" (=largest extreme value), "logistic" ,"loglogistic", "gamma", and
  # "beta" are implemented.
  #-shape is a vector for specifying the shape parameter(s) of distributions
  # such as the beta and gamma distribution (see Examples 2, 3, and 4 below)
  #-simplify: if TRUE then do not return a matrix containing the data points
  # (=data), standardized quantiles (=standardQuantile), and corresponding
  # probabilities.
  
  #plotting positions
  dataSorted <- data[order(data)]
  eventSorted <- event[order(data)]
  datai <- unique(dataSorted[which(eventSorted==1)])
  
  cumSurvRaw <- survfit(Surv(data, event)~ 1, weights=weight)
  cumSurv <- unique(rep(cumSurvRaw$surv, cumSurvRaw$n.event))
  cumFail <- 1-cumSurv
  lagFail <- c(0, cumFail[-length(cumFail)])
  Prob <- .5*(cumFail+lagFail)
  
  #labels for ticks along y-axis
  tick.probs <- c(.001,.005,.01,.02,.05,.1,.2,.3,.4,.5,.6,.7,.8,.9,.99,.999)
  
  #implement distributions
  if (dist=="lognormal" | dist=="gaussian") {
    yi <- qnorm(Prob) #plotting positions
    tick.pos <- qnorm(tick.probs) #positions for ticks along y-axis
    ylimr <- qnorm(range(tick.probs)) #range along y-axis
  }
  else if (dist=="exponential") {
    yi <- qexp(Prob) #plotting positions
    tick.pos <- qexp(tick.probs) #positions for ticks along y-axis
    ylimr <- qexp(range(tick.probs)) #range along y-axis
  }
  else if (dist=="weibull" | dist=="sev") {
    yi <- qsev(Prob) #plotting positions
    tick.pos <- qsev(tick.probs) #positions for ticks along y-axis
    ylimr <- qsev(range(tick.probs)) #range along y-axis
  }
  else if (dist=="frechet" | dist=="lev") {
    yi <- qlev(Prob) #plotting positions
    tick.pos <- qlev(tick.probs) #positions for ticks along y-axis
    ylimr <- qlev(range(tick.probs)) #range along y-axis
  }
  else if (dist=="loglogistic" | dist=="logistic") {
    yi <- qlogis(Prob) #plotting positions
    tick.pos <- qlogis(tick.probs) #positions for ticks along y-axis
    ylimr <- qlogis(range(tick.probs)) #range along y-axis
  }
  else if (dist=="gamma") {
    yi <- qgamma(Prob, shape=shape) #plotting positions
    tick.pos <- qgamma(tick.probs, shape=shape) #positions for ticks along y-axis
    ylimr <- qgamma(range(tick.probs), shape=shape) #range along y-axis
  }
  else if (dist=="beta") {
    yi <- qbeta(Prob, shape1=shape[1], shape2=shape[2]) #plotting positions
    tick.pos <- qbeta(tick.probs, shape1=shape[1], shape2=shape[2]) #positions for ticks along y-axis
    ylimr <- qbeta(range(tick.probs), shape1=shape[1], shape2=shape[2]) #range along y-axis
  }
  
  #determine range along x-axis
  rangeData <- range(data)
  
  #construct plot
  #distributions that require a log transform of the data scale
  if (dist=="weibull" | dist=="lognormal" | dist=="frechet" |
      dist=="loglogistic") {
    plot(0, type="n", log="x",
         xlim=c(rangeData[1], rangeData[2]),
         ylim=c(ylimr[1], ylimr[2]),
         xlab="Datos", ylab="Probabilidad", main=paste("distribuci�n",dist),
         axes=FALSE, frame.plot=TRUE)}
  else {
    plot(0, type="n",
         xlim=c(rangeData[1], rangeData[2]),
         ylim=c(ylimr[1], ylimr[2]),
         xlab="Data", ylab="Probabilidad", main=paste("distribution",dist),
         axes=FALSE, frame.plot=TRUE)}
  
  axis(2, at=tick.pos, labels=tick.probs)
  axis(1)
  points(datai, yi, col="red")
  #draw raster
  abline(h = tick.pos, lty=3, col="gray")
  abline(v = axTicks(1), lty=3, col="gray")
  
  #return plotting positions
  if (!simplify) cbind(data=datai, standardQuantile=yi, probability=Prob)
}

#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

#
#Function for predicting quantiles
#
predictData <- function (p, location=0, scale=1,
                         shape=NULL, rate=NULL, dist) {
  if (dist=="weibull") {exp(qsev(p)*scale + location)}
  else if (dist=="sev") {qsev(p)*scale + location}
  else if (dist=="frechet") {exp(qlev(p)*scale + location)}
  else if (dist=="lev") {qlev(p)*scale + location}
  else if (dist=="lognormal") {exp(qnorm(p)*scale + location)}
  else if (dist=="gaussian") {qnorm(p)*scale + location}
  else if (dist=="loglogistic") {exp(qlogis(p)*scale + location)}
  else if (dist=="logistic") {qlogis(p)*scale + location}
  else if (dist=="exponential") {qexp(p)*scale}
  else if (dist=="gamma") {qgamma(p, shape=shape)*scale}
  else if (dist=="beta") {qbeta(p, shape1=shape[1],
                                shape2=shape[2])*scale + location}
}


#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

#Interval and arbitrarily censored data

#CAUTION: the following function employs the type="interval" coding scheme as used
#in the "Surv" function (from the survival package) for coding interval
#and arbitrarily censored data.
#That is, events should be coded as: 0=right censored, 1=event at time,
#2=left censored, 3=interval censored.
#Have a look at the "Surv" function for more information on how to
#handle data when using the "interval" coding scheme.

#Function for constructing probability plots for
#interval and arbitrarily censored data
ProbPlotInterval <- function (time, time2=rep(NA, length(time)), event,
                              weight=rep(1, length(time)), dist,
                              shape=NULL, simplify=TRUE){
  #-time is the right/left censored value, the exact lifetime observation, or for
  # interval censoring the lower value of the censoring interval.
  #-time2 is the upper value of the censoring interval.
  #-event is the censoring indicator (0=right censored, 1=event at time,
  # 2=left censored, 3=interval censored).
  #-weight is an optional vector the weights for the observations
  #-dist is the assumed distribution for the data. Distributions "lognormal",
  # "gaussian", "exponential", "weibull", "sev" (=Gumbel), "frechet",
  # "lev" (=largest extreme value), "logistic" ,"loglogistic", "gamma", and
  # "beta" are implemented.
  #-shape is a vector for specifying the shape parameter(s) of distributions
  # such as the beta and gamma distribution (see Examples 2, 3, and 4 below).
  #-simplify: if TRUE then do not return a matrix containing the data points
  # (=data), standardized quantiles (=standardQuantile), and corresponding
  # probabilities.
  
  #plotting positions
  cumSurvRaw <- survfit(Surv(time=time, time2=time2,
                             event=event, type="interval") ~ 1,
                        weights=weight)
  
  cumSurv <- cumSurvRaw$surv
  cumFail <- 1-cumSurv
  Prob <- cumFail
  
  datai <- cumSurvRaw$time
  
  #labels for ticks along y-axis
  tick.probs <- c(.001,.005,.01,.02,.05,.1,.2,.3,.4,.5,.6,.7,.8,.9,.99,.999)
  
  #implement distributions
  if (dist=="lognormal" | dist=="gaussian") {
    yi <- qnorm(Prob) #plotting positions
    tick.pos <- qnorm(tick.probs) #positions for ticks along y-axis
    ylimr <- qnorm(range(tick.probs)) #range along y-axis
  }
  else if (dist=="exponential") {
    yi <- qexp(Prob) #plotting positions
    tick.pos <- qexp(tick.probs) #positions for ticks along y-axis
    ylimr <- qexp(range(tick.probs)) #range along y-axis
  }
  else if (dist=="weibull" | dist=="sev") {
    yi <- qsev(Prob) #plotting positions
    tick.pos <- qsev(tick.probs) #positions for ticks along y-axis
    ylimr <- qsev(range(tick.probs)) #range along y-axis
  }
  else if (dist=="frechet" | dist=="lev") {
    yi <- qlev(Prob) #plotting positions
    tick.pos <- qlev(tick.probs) #positions for ticks along y-axis
    ylimr <- qlev(range(tick.probs)) #range along y-axis
  }
  else if (dist=="loglogistic" | dist=="logistic") {
    yi <- qlogis(Prob) #plotting positions
    tick.pos <- qlogis(tick.probs) #positions for ticks along y-axis
    ylimr <- qlogis(range(tick.probs)) #range along y-axis
  }
  else if (dist=="gamma") {
    yi <- qgamma(Prob, shape=shape) #plotting positions
    tick.pos <- qgamma(tick.probs, shape=shape) #positions for ticks along y-axis
    ylimr <- qgamma(range(tick.probs), shape=shape) #range along y-axis
  }
  else if (dist=="beta") {
    yi <- qbeta(Prob, shape1=shape[1], shape2=shape[2]) #plotting positions
    tick.pos <- qbeta(tick.probs, shape1=shape[1], shape2=shape[2]) #positions for ticks along y-axis
    ylimr <- qbeta(range(tick.probs), shape1=shape[1], shape2=shape[2]) #range along y-axis
  }
  
  #determine range along x-axis
  rangeData <- range(cumSurvRaw$time)
  
  #construct plot
  #distributions that require a log transform of the data scale
  if (dist=="weibull" | dist=="lognormal" | dist=="frechet" |
      dist=="loglogistic") {
    plot(0, type="n", log="x",
         xlim=c(rangeData[1], rangeData[2]),
         ylim=c(ylimr[1], ylimr[2]),
         xlab="Data", ylab="Probability", main=paste(dist, "distribution"),
         axes=FALSE, frame.plot=TRUE)}
  else {
    plot(0, type="n",
         xlim=c(rangeData[1], rangeData[2]),
         ylim=c(ylimr[1], ylimr[2]),
         xlab="Data", ylab="Probability", main=paste(dist, "distribution"),
         axes=FALSE, frame.plot=TRUE)}
  
  axis(2, at=tick.pos, labels=tick.probs)
  axis(1)
  points(datai, yi, col="red")
  #draw raster
  abline(h = tick.pos, lty=3, col="gray")
  abline(v = axTicks(1), lty=3, col="gray")
  
  #return plotting positions
  if (!simplify) cbind(data=datai, standardQuantile=yi, probability=Prob)
}

#Function for predicting quantiles
predictData <- function (p, location=0, scale=1,
                         shape=NULL, rate=NULL, dist) {
  if (dist=="weibull") {exp(qsev(p)*scale + location)}
  else if (dist=="sev") {qsev(p)*scale + location}
  else if (dist=="frechet") {exp(qlev(p)*scale + location)}
  else if (dist=="lev") {qlev(p)*scale + location}
  else if (dist=="lognormal") {exp(qnorm(p)*scale + location)}
  else if (dist=="gaussian") {qnorm(p)*scale + location}
  else if (dist=="loglogistic") {exp(qlogis(p)*scale + location)}
  else if (dist=="logistic") {qlogis(p)*scale + location}
  else if (dist=="exponential") {qexp(p)*scale}
  else if (dist=="gamma") {qgamma(p, shape=shape)*scale}
  else if (dist=="beta") {qbeta(p, shape1=shape[1],
                                shape2=shape[2])*scale + location}
}

#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%




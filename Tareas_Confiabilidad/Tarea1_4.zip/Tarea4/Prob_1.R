x<-seq(0,1,by=0.01)
t<-1+qlogis(x)

plot(t[-c(1,101)],log(x[-c(1,101)]/(1-x[-c(1,101)])),xlab = "Tiempo", 
     ylab = "Fracci�n de falla",type = "l", yaxt='n',col="red3",xaxt='n')

t<-1+2*log(x/(1-x))

points(t[-c(1,101)],log(x[-c(1,101)]/(1-x[-c(1,101)])),type = "l",
       col="royalblue3")

text(locator(), 
     labels = c(expression(paste(mu,"=1, ",sigma,"=1")),expression(paste(mu,"=1, ",sigma,"=2"))))

grid()

x<-seq(0,1,by=0.05)
t<-seq(25,300,by=25)
axis(2,log(x/(1-x)),labels =x)
axis(2,log(0.01/(1-0.01)),labels =0.01)
axis(2,log(0.99/(1-0.99)),labels =0.99)
axis(1,log(t),labels = t)
t<-seq(1,25,by=2.5)
axis(1,log(t),labels = t)
t<-seq(0.1,0.99,by=0.05)
axis(1,log(t),labels = t)

x<-seq(-5,5,by=1)
axis(4,x,labels = x)


#############################Aqui No pasa nada

x<-seq(0,1,by=0.01)
t<-6.2+2*qnorm(x)

exp(t)

plot(t[-c(1,101)],qnorm(x[-c(1,101)]),xlab = "Tiempo", 
     ylab = "Fracci�n de falla",type = "l", yaxt='n',col="red3")

axis(1,t,labels = exp(t))
     
points(0.5)

t<-1.7+2*qnorm(x)

t

plot(t,qnorm(x))

t<-1.7+qnorm(x)

points(t,qnorm(x))


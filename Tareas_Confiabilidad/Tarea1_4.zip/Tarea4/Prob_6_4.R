t<-c(0.74,1.21,0.22,0.37,1.28,0.73,0.99,0.67,0.71,0.33)
p<-c()

for (i in 1:10) {
  p[i]<-(i-0.5)/10
}

p

plot(log(sort(t)),qsev(p),xaxt='n',yaxt='n',
     ylab = "Fracci�n de falla",xlab = "Tiempo",col="royalblue")

axis(2,at=qsev(p),labels = p,las=1)

axis(1,at=log(sort(t)),labels = sort(t),las=2)

abline(lm(qsev(p)~log(sort(t))))

grid()

segments(-1.8,qsev(0.632),(qsev(0.632)-0.389)/2.1,qsev(0.632))

segments((qsev(0.632)-0.389)/2.1,-4.6,(qsev(0.632)-0.389)/2.1,qsev(0.632))

axis(1,at=(qsev(0.632)-0.389)/2.1,labels = 0.83,las=2)

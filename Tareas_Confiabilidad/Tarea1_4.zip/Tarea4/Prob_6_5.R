t<-c(17.88,28.92,33,41.52,42.12,45.6,48.4,51.84,51.96,54.12,55.56,67.8
     ,68.64,68.64,68.88,84.12,93.12,98.64,105.12,105.84,127.92,128.04,
     173.4)

f<-c()

curve(0*x,0,t[1]-0.1,xlim = c(0,180),ylim=c(0,1),
      ylab="Proporcion de Falla",xlab = "Ciclos en Millones",
      main="Estimaci�n no-Parametrica",xaxt='n')

for (i in 2:length(t)) {
  if(i!=length(t)) {
    curve((i-1)/23 * x/x,t[i-1],t[i]-0.1,add = TRUE)
  }else{
    curve((i-1)/23 * x/x,t[i-1],173.4-0.1,add = TRUE)
    curve(1*x/x,173.4,173.5,add=TRUE)
  }
}

points(c(0,t),seq(0,length(t),by=1)/23,col="royalblue")

axis(1,at=c(0,t),labels = c(0,t),las=2)

p<-c()

for (i in 1:length(t)) {
  p[i]<-(i-0.5)/23
}

plot(log(t),qnorm(p),xaxt='n',yaxt='n',xlab = "Ciclos en Millones",
     ylab = "Proporci�n de Falla", main = "Gr�fica de Probabilidad Lognormal",
     col="royalblue")

axis(1,at=log(t),labels = t,las=2)

axis(2,at=qnorm(p),labels = round(p,2),las=1)

grid()

abline(lm(qnorm(p)~log(t)))

plot(log(t),qsev(p),xaxt='n',yaxt='n',xlab = "Ciclos en Millones",
     ylab = "Proporci�n de Falla", main = "Gr�fica de Probabilidad Weibull",
     col="royalblue")

axis(1,at=log(t),labels = t,las=2)

axis(2,at=qsev(p),labels = round(p,2),las=1)

grid()

abline(lm(qsev(p)~log(t)))

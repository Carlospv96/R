
t<-c(564,1104,1321,1933,1965,2345,2578,3122,4467,5918,6623,7885,7912,
     8156,12229)

d<-c(0,1,0,0,0,1,0,0,1,0,1,1,0,0,0)

r<-c(3,0,2,3,3,0,2,3,0,2,0,0,2,3,2)

p<-c()

s<-c()

f<-c()

for (i in 1:length(t)) {
  
  if (i==1){
    
    p[i]<-d[i]/30
    
    s[i]<-prod(1-p)
    
    f[i]<-1-s[i]
    
  }else{
    
    n<-30-sum(d[1:(i-1)])-sum(r[1:(i-1)])
    
    p[i]<-d[i]/n
    
    s[i]<-prod(1-p[1:i])
    
    f[i]<-1-s[i]
    
  }
  
}

p<-c()

p[2]=0.5*(f[2]+f[1])
p[6]=0.5*(f[6]+f[5])
p[9]=0.5*(f[9]+f[8])
p[11]=0.5*(f[11]+f[10])
p[12]=0.5*(f[12]+f[11])

p

plot(log(t[c(2,6,9,11,12)]),qsev(p[c(2,6,9,11,12)]),
     xlim = c(log(t[2]),11),
     ylim = c(qsev(0.001),qsev(0.99)),xaxt='n',yaxt='n',xlab = "Ciclos",
     ylab = "Proporci�n de Falla",main = "Gr�fica de Probabilidad Weibull",
     col="royalblue")

axis(1,at=log(t[c(2,6,9,11,12)]),labels = t[c(2,6,9,11,12)],las=2)

axis(1,at=9.729688,labels = 16809.31,las=2)

axis(2,at=qsev(p[c(2,6,9,11,12)]),labels = round(p[c(2,6,9,11,12)],3),las=1)

axis(2,at=qsev(seq(0.4,0.99,by=0.05)),labels = seq(0.4,0.99,by=0.05),las=1)

axis(2,at=qsev(seq(0.001,0.009,by=0.003)),labels = seq(0.001,0.009,by=0.003),las=1)

abline(lm(qsev(p[c(2,6,9,11,12)])~log(t[c(2,6,9,11,12)])))

grid()

segments(0,qsev(0.632),9.729688,qsev(0.632))

segments(9.729688,qsev(0.0001),9.729688,qsev(0.632))

x<-seq(0,1,by=0.01)
abline(0,0.5)

t<-c(18,32,39,53,59,68,77,78,93)

curve(0*x,0,t[1]-0.1,xlim = c(0,100),ylim=c(0,0.1),
      ylab = "Proporci�n de Falla",xlab = "t",
      main="Estimaci�n no-Parametrica")
curve(1/100 * x/x,t[1],t[2]-0.1,add = TRUE)
curve(2/100 * x/x,t[2],t[3]-0.1,add = TRUE)
curve(3/100 * x/x,t[3],t[4]-0.1,add = TRUE)
curve(4/100 * x/x,t[4],t[5]-0.1,add = TRUE)
curve(5/100 * x/x,t[5],t[6]-0.1,add = TRUE)
curve(6/100 * x/x,t[6],t[7]-0.1,add = TRUE)
curve(7/100 * x/x,t[7],t[8]-0.1,add = TRUE)
curve(8/100 * x/x,t[8],t[9]-0.1,add = TRUE)
curve(9/100 * x/x,t[9],100,add = TRUE)

points(c(0,t),seq(0,9,by=1)/100,col="royalblue")

t<-c()
d<-seq(1,1,length.out = 9)
n<-c()
p<-c()
s<-c()
f<-c()

for (i in 1:9) {
  
  if (i==1) {
    
    n[i]=100
    p[i]=d[i]/n[i]
    s[i]=prod(1-p)
    f[i]<-1-s[i]
    
  }else{
    
    n[i]=100-sum(d[1:i-1])
    p[i]=d[i]/n[i]
    s[i]=prod(1-p)
    f[i]<-1-s[i]
    
  }
  
}

p1<-c(f[1]/2)

for (i in 2:9) {
  p1[i]<-1/2 * (f[i-1]+f[i])
}

t<-c(18,32,39,53,59,68,77,78,93)

p<-c()

for (i in 1:9) {
  p[i]<-(i-0.5)/100
}

plot(log(t),qsev(p),xaxt='n',yaxt='n',ylim = qsev(c(0.001,0.99)),
     xlab = "Tiempo en miles de horas",
     ylab = "Fracci�n de Falla",col="royalblue",
     main="Gr�fica de Probabilidad")

axis(1,at=log(t),labels = t,las=2)

axis(2,at=qsev(p),labels = p,las=1)

axis(2,at=qsev(seq(0.1,0.95,0.05)),labels = seq(0.1,0.95,0.05),las=1)

abline(lm(qsev(p)~log(t)))

grid()

plot(log(t),qsev(p),xaxt='n',yaxt='n',ylim = qsev(c(0.001,0.99)),
     xlim = c(log(t[1]),log(350)),
     xlab = "Tiempo en miles de horas",
     ylab = "Fracci�n de Falla",col="royalblue",
     main="Gr�fica de Probabilidad")

axis(1,at=log(t),labels = t,las=2)

axis(1,at=5.848591,labels = 346.75,las=2)

axis(2,at=qsev(p),labels = p,las=1)

axis(2,at=qsev(seq(0.1,0.95,0.05)),labels = seq(0.1,0.95,0.05),las=1)

abline(lm(qsev(p)~log(t)))

grid()

segments(0,qsev(0.632),5.848591,qsev(0.632))

segments(5.848591,qsev(0.00001),5.848591,qsev(0.632))

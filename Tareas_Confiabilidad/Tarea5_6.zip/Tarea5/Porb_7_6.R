t<-c(7.74,17.05,20.46,21.02,22.66,43.4,47.30)

n<-11

p<-c()

for (i in 1:7) {
  p[i]<-(i-0.5)/n
}

plot(log(t),qsev(p),main = "Gr�fica de Probabilidad Weibull",
     xaxt='n',yaxt='n',xlab = "Horas",ylab = "Proporci�n de falla",
     col="springgreen",pch=16,ylim = c(qsev(0.0001),qsev(0.9999)))

axis(1,at=log(t), labels = t,las=2)

axis(2,at=qsev(p[1:6]), labels = round(p[1:6],3),las=1)

axis(2,at=c(qsev(0.632),qsev(seq(0.75,0.95,by=0.1)),qsev(0.9999)),
     labels =c(0.632,seq(0.75,0.95,by=0.1),0.99),las=1 )

axis(2,at=c(qsev(0.0001),qsev(seq(0.01,0.03,by=0.01))),labels=c(0.0001,seq(0.01,0.03,by=0.01)),
     las=1)

grid()

abline(lm(qsev(p)~log(t)))

plot(t,-log(1-p),main = "Gr�fica de Probabilidad Exponencial",
     xaxt='n',yaxt='n',xlab = "Horas",ylab = "Proporci�n de falla",
     col="springgreen",pch=16,ylim = c(-log(1-0.0001),-log(1-0.99)))

axis(1,at=t, labels = t,las=2)

axis(2,at=-log(1-p),labels = round(p,3),las=1)

axis(2,at=-log(1-seq(0.65,0.99,by=0.1)),labels = seq(0.65,0.99,by=0.1),
     las=1)

axis(2,at=-log(1-0.99),labels = 0.99,las=1)

abline(lm(-log(1-p)~t))

grid()

2*(sum(t)+4*100)/7

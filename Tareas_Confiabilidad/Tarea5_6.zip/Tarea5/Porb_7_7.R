t<-c(8,11,12,13,19,21,28,34,36,44)
############### (a)

p<-c()

for (i in 1:length(t)) {
  p[i]<-(i-0.5)/50
}

plot(t,-log(1-p),ylim = c(-log(1-0.0001),-log(1-0.99)),xaxt='n',
     yaxt='n',xlab = "Horas",ylab = "Proporci�n de Fallas",
     main = "Gr�fica de Probabilidad Exponencial",col="springgreen",
     pch=16)

axis(1,at=t,labels = t,las=2)

axis(2,at=-log(1-p[1]),labels = round(p[1],3),las=1)

axis(2,at=-log(1-seq(0.15,0.95,by=0.1)),labels = seq(0.15,0.95,by=0.1),
     las=1)

axis(2,at=-log(1-0.99),labels = 0.99,las=1)

abline(lm(-log(1-p)~t))

grid()

############# (b)

(sum(t)+40*t[10])/10

############## (c)

198.6/sqrt(10)


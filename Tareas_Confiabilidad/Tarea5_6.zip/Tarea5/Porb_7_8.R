######### 7.8

t<-c(8,11,12,13,19,21,28,34,36,44)

p<-c()

for (i in 1:length(t)) {
  p[i]<-(i-0.5)/50
}

plot(t,-log(1-p),ylim = c(-log(1-0.0001),-log(1-0.2)),xaxt='n',
     yaxt='n',xlab = "Horas",ylab = "Proporci�n de Fallas",
     main = "Gr�fica de Probabilidad Exponencial",col="springgreen",
     pch=16)

axis(1,at=t,labels = t,las=2)

axis(2,at=-log(1-p[1]),labels = round(p[1],3),las=1)

axis(2,at=-log(1-seq(0.05,0.2,by=0.05)),labels = seq(0.05,0.2,by=0.05),
     las=1)

axis(2,at=-log(1-0.99),labels = 0.99,las=1)

grid()

curve(1-exp(-x/198.6),0,46,add=TRUE)

curve(1-exp(-x/116.2),0,46,add = TRUE,col="mediumslateblue")

curve(1-exp(-x/413.75),0,46,add = TRUE,col="mediumslateblue")

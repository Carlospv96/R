library(survival)
library(SPREDA)
#PROBLEMA 8.2 
t=c(rep(1,103),rep(2,100),rep(3,97))
event=c(1,1,1,1,rep(0,99),1,1,1,1,1,rep(0,95),1,1,rep(0,95))

##a)
#Estimaci�n de los parametros
r=11
theta=sum(t)/r
theta

#Ajuste de la distribuci�n
library(flexsurv)
#para la weibull se ingresan los valores de eta y beta
#Funci�n para construir gr�ficos de probabilidad para datos
#completos (sin censura) y censurados a la derecha
ProbPlot<-function (data, event=rep(1, length(data)),
                    weight=rep(1, length(data)), dist,theta,
                    shape=NULL, simplify=TRUE){
    
    #trazar posiciones
    dataSorted<-data[order(data)]  #ordena las observaciones
    eventSorted<-event[order(data)]
    datai<-unique(dataSorted[which(eventSorted==1)]) #quita las observaciones duplicadas
    
    cumSurvRaw<-survfit(Surv(data, event)~ 1, weights=weight)
    cumSurv <- unique(rep(cumSurvRaw$surv, cumSurvRaw$n.event))
    cumFail <- 1-cumSurv
    lagFail <- c(0, cumFail[-length(cumFail)])
    Prob <- .5*(cumFail+lagFail)
    
    #etiquetas para marcas a lo largo del eje y
    tick.probs <- c(.001,.005,.01,.02,.05,.1,.2,.3,.4)
    #,.5,.6,.7,.8,.9,.99,.999)
    
    # extra para la estimacion MV 
    mu1=1/theta
    q=seq(0,100, by=0.005)
    Prob2 <- pexp(q,mu1) #plotting positions
    xi2=qexp(Prob2,mu1)
    yi2<- qexp(Prob2) #plotting positions
 
    #fin extra
    #implementar distribuciones
    if (dist=="lognormal" | dist=="gaussian") {
        yi <- qnorm(Prob) #trazar posiciones
        tick.pos <- qnorm(tick.probs) #posiciones para ticks a lo largo del eje y
        ylimr <- qnorm(range(tick.probs)) #rango a lo largo del eje y
    }
    else if (dist=="exponential") {
        yi<-qexp(Prob) #plotting positions
        tick.pos <- qexp(tick.probs) #positions for ticks along y-axis
        ylimr <- qexp(range(tick.probs)) #range along y-axis
    }
    else if (dist=="weibull" | dist=="sev") {
        yi <- qsev(Prob) #plotting positions
        tick.pos <- qsev(tick.probs) #positions for ticks along y-axis
        ylimr <- qsev(range(tick.probs)) #range along y-axis
    }
    else if (dist=="frechet" | dist=="lev") {
        yi <- qlev(Prob) #plotting positions
        tick.pos <- qlev(tick.probs) #positions for ticks along y-axis
        ylimr <- qlev(range(tick.probs)) #range along y-axis
    }
    else if (dist=="loglogistic" | dist=="logistic") {
        yi <- qlogis(Prob) #plotting positions
        tick.pos <- qlogis(tick.probs) #positions for ticks along y-axis
        ylimr <- qlogis(range(tick.probs)) #range along y-axis
    }
    else if (dist=="gamma") {
        yi <- qgamma(Prob, shape=shape) #plotting positions
        tick.pos <- qgamma(tick.probs, shape=shape) #positions for ticks along y-axis
        ylimr <- qgamma(range(tick.probs), shape=shape) #range along y-axis
    }
    else if (dist=="beta") {
        yi <- qbeta(Prob, shape1=shape[1], shape2=shape[2]) #plotting positions
        tick.pos <- qbeta(tick.probs, shape1=shape[1], shape2=shape[2]) #positions for ticks along y-axis
        ylimr <- qbeta(range(tick.probs), shape1=shape[1], shape2=shape[2]) #range along y-axis
    }
    
    #determinar el rango a lo largo del eje x
    rangeData <- range(data)
    
    #construct plot
    #distribuciones que requieren una transformaci�n logar�tmica de la escala de datos
    
    if (dist=="weibull" | dist=="lognormal" | dist=="frechet" |
        dist=="loglogistic") {
        plot(0, type="n", log="x",
             xlim=c(rangeData[1], rangeData[2]),
             ylim=c(ylimr[1], ylimr[2]),
             xlab="Datos", ylab="Probabilidad", main=paste("distribuci�n",dist),
             axes=FALSE, frame.plot=TRUE)}
    else {
        plot(0, type="n",
             xlim=c(rangeData[1], rangeData[2]),
             ylim=c(ylimr[1], ylimr[2]),
             xlab="Tiempo en a�os", ylab="Proporci�n de falla", main="Distribuci�n Exponencial",
             axes=FALSE, frame.plot=TRUE)}
    
    axis(2, at=tick.pos, labels=tick.probs)
    axis(1)
    points(datai, yi, col="red",pch=19)
    points(xi2, yi2, col="black",type ="l")  ##extra para la linea de MV
 
    #draw raster
    abline(h = tick.pos, lty=3, col="gray")
    abline(v = axTicks(1), lty=3, col="gray")
    
    #volver a trazar posiciones
    if (!simplify) cbind(data=datai, standardQuantile=yi, probability=Prob)
}
#%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
datos=t
ProbPlot(data=datos, event=event,
         weight=rep(1, length(datos)), "exponential",theta=theta,
         shape=NULL, simplify=TRUE)

##b)
#Estimaci�n de los parametros
fit=Lifedata.MLE(Surv(t, event)~1, dist="weibull")
dat=summary(fit)
#Estimaci�n de eta 
a=exp(dat$coef[1])
beta= 1/dat$coef[2]
#Los estimadores de b,u,eta,beta,l() son:
dat$coef[2];dat$coef[1];a;beta;-dat$min

#Grafica de ajuste
#para la weibull se ingresan los valores de eta y beta
#Funci�n para construir gr�ficos de probabilidad para datos
#completos (sin censura) y censurados a la derecha
t=c(rep(1,103),rep(2,100),rep(3,97))
event=c(1,1,1,1,rep(0,99),1,1,1,1,1,rep(0,95),1,1,rep(0,95))

datos=t
data=datos; event=event
weight=rep(1, length(datos)); dist="weibull"
shape=NULL; simplify=TRUE



#trazar posiciones
dataSorted<-data[order(data)]  #ordena las observaciones
eventSorted<-event[order(data)]
datai<-unique(dataSorted[which(eventSorted==1)]) #quita las observaciones duplicadas

cumSurvRaw<-survfit(Surv(data, event)~ 1, weights=weight)
cumSurv <- unique(rep(cumSurvRaw$surv, cumSurvRaw$n.event))
cumFail <- 1-cumSurv
lagFail <- c(0, cumFail[-length(cumFail)])
Prob <- .5*(cumFail+lagFail)

#etiquetas para marcas a lo largo del eje y
tick.probs <- c(.001,.005,.01,.02,.05,.1,.2,.3,.4,.5,.6,.7,.8,.9,.99,.999)

# extra para la estimacion MV 
beta=beta
eta=a
q=seq(0,100, by=0.005)
Prob2 <- pweibull(q,beta,eta) #plotting positions
xi2=q
yi2<-qsev(Prob2) #plotting positions
Prob3=pweibull(q,1,theta)
yi3<-qsev(Prob3)
#fin extra
#implementar distribuciones
if (dist=="lognormal" | dist=="gaussian") {
    yi <- qnorm(Prob) #trazar posiciones
    tick.pos <- qnorm(tick.probs) #posiciones para ticks a lo largo del eje y
    ylimr <- qnorm(range(tick.probs)) #rango a lo largo del eje y
}else if (dist=="exponential") {
    yi<-qexp(Prob) #plotting positions
    tick.pos <- qexp(tick.probs) #positions for ticks along y-axis
    ylimr <- qexp(range(tick.probs)) #range along y-axis
}else if (dist=="weibull" | dist=="sev") {
    yi <- qsev(Prob) #plotting positions
    tick.pos <- qsev(tick.probs) #positions for ticks along y-axis
    ylimr <- qsev(range(tick.probs)) #range along y-axis
}else if (dist=="frechet" | dist=="lev") {
    yi <- qlev(Prob) #plotting positions
    tick.pos <- qlev(tick.probs) #positions for ticks along y-axis
    ylimr <- qlev(range(tick.probs)) #range along y-axis
}else if (dist=="loglogistic" | dist=="logistic") {
    yi <- qlogis(Prob) #plotting positions
    tick.pos <- qlogis(tick.probs) #positions for ticks along y-axis
    ylimr <- qlogis(range(tick.probs)) #range along y-axis
}else if (dist=="gamma") {
    yi <- qgamma(Prob, shape=shape) #plotting positions
    tick.pos <- qgamma(tick.probs, shape=shape) #positions for ticks along y-axis
    ylimr <- qgamma(range(tick.probs), shape=shape) #range along y-axis
}else if (dist=="beta") {
    yi <- qbeta(Prob, shape1=shape[1], shape2=shape[2]) #plotting positions
    tick.pos <- qbeta(tick.probs, shape1=shape[1], shape2=shape[2]) #positions for ticks along y-axis
    ylimr <- qbeta(range(tick.probs), shape1=shape[1], shape2=shape[2]) #range along y-axis
}

#determinar el rango a lo largo del eje x
rangeData <- range(data)

#construct plot
#distribuciones que requieren una transformaci�n logar�tmica de la escala de datos

if (dist=="weibull" | dist=="lognormal" | dist=="frechet" |
    dist=="loglogistic"){
    plot(0, type="n", log="x",
         xlim=c(rangeData[1], rangeData[2]),
         ylim=c(ylimr[1], ylimr[2]),
         xlab="Datos", ylab="Proporcion de Falla", main=paste("Distribuci�n",dist),
         axes=FALSE, frame.plot=TRUE)
}else{
    plot(0, type="n",
         xlim=c(rangeData[1], rangeData[2]),
         ylim=c(ylimr[1], ylimr[2]),
         xlab="Data", ylab="Probabilidad", main=paste("distribution",dist),
         axes=FALSE, frame.plot=TRUE)}

axis(2, at=tick.pos, labels=tick.probs)
axis(1)
points(datai, yi, col="red",pch=19)
points(xi2, yi2, col="darkgoldenrod1",type ="l")  ##extra para la linea de MV
points(xi2, yi3, col="black",type ="l") #extra pa la exp
#draw raster
abline(h = tick.pos, lty=3, col="gray")
abline(v = axTicks(1), lty=3, col="gray")

#volver a trazar posiciones
if (!simplify) cbind(data=datai, standardQuantile=yi, probability=Prob)

#----------------------------------------------------------------------------------------------
#Problema 8.3 
#El valor de la logverosimilitud considerando la estimacion usual es 
l1=-dat$min #dat$min del ejercicio 8.2 b)

#Considerando la hipotesis nula:
#b=1 (beta=1)
    #Estimaci�n de u (no necesaria porque es igual a log(theta) estimado)
b0=1
    #r=11 #hay 11 fallas
    #u=b0*log((1/r)*sum(exp(log(t)/b0)))
u=log(theta)
u
#Log-verosimilitud evaluada en u y b0
library(WeibullR)
x=c(rep(1,4),rep(2,5),3,3)
s=c(rep(1,99),rep(2,95),rep(3,95))
datos=mleframe(x, s, interval=NULL) #tipo de dato que requiere la funcion wblrloglike
#x  son tiempos de falla
#s son tiempos de censura
l2=wblrLoglike(c(1/b0,exp(u)), datos,dist="weibull") #c(shape,scale)
l2
##Estadistico lamda
lamda=2*(l1-l2)
lamda
#cuantil 99
qchisq(0.99, df=1, ncp=0, lower.tail = TRUE, log.p = FALSE)

#-------------------------------------------------------------------------------------
#PROBLEMA 8.4
z=qnorm(0.975)
#Matriz de covarianza
dat$vcov
#sesgo de F
var_u=dat$vcov[1,1]
var_b=dat$vcov[2,2]
cov=dat$vcov[1,2]
b=dat$coef[2]
u=dat$coef[1]
c_2=(log(2)-u)/b
f_gorro=dsev(c_2)
sesgo=(f_gorro/b)*sqrt(var_u+2*c_2*cov+c_2*c_2*var_b)
sesgo
#Intervalo
F_gorro=psev(c_2)
F_inf=F_gorro-z*sesgo
F_sup=F_gorro+z*sesgo
F_inf
F_sup

#INTERVALO INCISO b)
w=exp(z*sesgo/(F_gorro*(1-F_gorro)))
w
lim_inf=F_gorro/(F_gorro+(1-F_gorro)*w)
lim_sup=F_gorro/(F_gorro+(1-F_gorro)/w)
lim_inf
lim_sup
    
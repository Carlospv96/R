
#Inciso a

t<-c(18,32,39,53,59,68,77,78,93)

sqrt(sum(t^2,rep(100^2,times=91))/9)

#Inciso b

323.9419/2 * sqrt(1/9)

#INCISO C

323.9419-(1.96)*(53.99032)

323.9419+(1.96)*(53.99032)

#INCISO D

curve(pweibull(x,shape=2,scale = 323.9419),0,100,col="red",pch=19,
     ylim = c(0,0.2),xlim = c(0,100),ylab = "Proporci�n de Falla",
     xlab = "Ciclos",main = "Gr�fica de Estimaci�n de F(t)")

f<-c()

legend(0,0.2,legend = c("Estimaci�n F(t)","Estimaci�n No Parametrica"),
       col = c("red","darkgoldenrod1"),lty = c(1,NA),pch = c(NA,19),box.lty = 0)

for (i in 1:9) {
 
  f[i]<-i/100
   
}

points(t,f,col="darkgoldenrod1",pch=19)

grid()

#INCISO E

323.9419*sqrt(-log(0.9))

#INCISO F

218.1209*sqrt(-log(0.9))

429.7629*sqrt(-log(0.9))

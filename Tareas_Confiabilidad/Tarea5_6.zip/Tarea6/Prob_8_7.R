t<-c(252,315,369,403,474)

p<-c()

for (i in 1:length(t)) {
  p[i]<-(i-0.5)/20
}

plot(log(t),qnorm(p),
     main = "Gr�fica de Probabilidad Lognormal para las fallas de los CI",
     xaxt='n',yaxt='n',ylab = "Proporci�n de Falla", xlab = "t",
     ylim = c(qnorm(0.01),qnorm(0.99)),xlim=c(log(200),log(650)),
     col="red",pch=19)

axis(1,at=log(t),labels = t,las=2)

axis(2,at=c(qnorm(p),qnorm(seq(0.5,0.9,by=0.1))),
     labels = c(p,seq(0.5,0.9,by=0.1)),las=1)

axis(2,at=qnorm(0.99),labels = 0.99,las=1)

grid()

#####Inciso b

plnorm(200,mean = 6.56,sd=0.534)

plnorm(1000,mean = 6.56,sd=0.534)

plot(log(t),qnorm(p),
     main = "Gr�fica de Probabilidad Lognormal para las fallas de los CI",
     xaxt='n',yaxt='n',ylab = "Proporci�n de Falla", xlab = "t",
     ylim = c(qnorm(0.01),qnorm(0.99)),col="red",
     xlim = c(log(190),log(1000)),pch=19)

grid()

a<-c(log(200),log(1000))

b<-c(qnorm(plnorm(200,mean = 6.56,sd=0.534)),qnorm(plnorm(1000,mean = 6.56,sd=0.534)))

points(a,b,col="darkgoldenrod1",pch=19)

axis(1,at=log(t),labels = t,las=2)

axis(2,at=c(qnorm(p),qnorm(seq(0.5,0.9,by=0.1))),
     labels = c(p,seq(0.5,0.9,by=0.1)),las=1)

axis(2,at=qnorm(0.99),labels = 0.99,las=1)

abline(lm(b~a))
       
#############inciso c

exp(6.56+0.5*(0.534)^2)

exp(6.56)

#############inciso d

exp(6.56+qnorm(0.1)*0.534)

#############inciso e

356.2567*(0.0581+2*(qlnorm(0.1))*(0.0374)+(qlnorm(0.1))^2 * (0.0405)) ^(1/2)

##############inciso f

exp(1.96*(102.0077)/356.2567)

t1<-356.2567/1.752793
t2<-356.2567*1.752793

t1
t2

points(log(t1),
       qnorm(0.01),pch=4,col="darkgreen")

points(log(t2),
       qnorm(0.01),pch=4,col="darkgreen")

points(log(356.2567),qnorm(0.01),
       col="darkgoldenrod1",pch=19)

axis(1,at=log(356.2567),labels = expression('t'[0.1]),las=2)

axis(2,at=qnorm(0.01),labels = 0,las=1)

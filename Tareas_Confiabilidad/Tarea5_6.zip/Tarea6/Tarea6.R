#Problema 6

#Inciso a)

data=c(0.82, 0.99, 1.06, 1.08, 1.24, 1.39, 1.40) #7 fallas, 13 censuras en 1.5

p=c()

for (i in 1:length(data)) {
  p[i]<-(i-0.5)/20
}

plot(log(data),qsev(p),
     main = "Gr�fica de Probabilidad Weibull para las fallas de los t.t.RF",
     xaxt='n',yaxt='n',ylab = "Proporci�n de Falla", xlab = "Tiempo en miles de horas",
     ylim = c(qsev(0.01),qsev(0.99)),col="red",pch=19)

tick.probs <- c(.001,.005,.01,.02,.05,.1,.2,.3,.4,.5,.6,.7,.8,.9,.99,.999)
tick.pos <- qsev(tick.probs) 
axis(2, at=tick.pos, labels=tick.probs,las=1)

axis(1,at=log(data),labels = data,las=2)

grid()

#Hacer una estimaci�n de eta y beta mediante la regresi�n lineal

abline(reglin)
reglin=lm(qsev(p)~log(data))
reglin

#Para graficar  el estimador de F(t) #inciso b)
x<-seq(0,1,by=0.01)
t<-log(eta)+(1/b)*(log(-log(1-x)))

points(t[-c(1,101)],(log(-log(1-x[-c(1,101)]))),type = "l",
       col="darkgoldenrod1")

#Inciso b) 
b=3
r=7
datos=c(0.82, 0.99, 1.06, 1.08, 1.24, 1.39, 1.40,1.5,1.5,1.5,1.5,1.5,1.5,
       1.5,1.5,1.5,1.5,1.5,1.5,1.5)
suma=0
for (i in 1:20) {
  suma=suma+((datos[i])^(b))
}
eta=(suma/r)^(1/b)
eta     

#Inciso c), calculos

se=(eta/b)*(sqrt(1/7))
se
etasup=eta+(se*qnorm(0.975))
etainf=eta-(se*qnorm(0.975))

etainf
etasup
#Inciso d), Calculos

1-exp(-((1/etasup)^(3)))
1-exp(-((1/etainf)^(3)))

#&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&

#Ejericicio 8.11
data=c(450, 460, 1150, 1600, 1660, 1850, 2030, 2070, 2080, 2200, 3000
       ,3100, 3450, 3750, 4150, 4300, 4600, 4850, 5000, 6100,6100, 6300, 6450
       ,6700, 7450, 7800, 8100, 8200, 8500, 8750,8750, 9400, 9900, 10100, 11500)

event=c(1,0,1,1,0,0,0,1,1,0,0,1,1,0,0,0,1,0,0,1,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0)
weight=c(1,1,2,1,1,5,3,2,1,1,4,1,1,2,4,4,1,4,3,1,3,1,2,1,1,2,2,1,3,1,2,1,1,3,1)

#Realizar la graficas a) y b)
ProbPlot(data,event,weight,dist="exponential",shape=NULL, simplify=TRUE)
ProbPlot(data,event,weight,dist="weibull",shape=NULL, simplify=TRUE)


ProbPlot <- function (data, event=rep(1, length(data)),
                      weight=rep(1, length(data)), dist,
                      shape=NULL, simplify=TRUE){
  #-data is a vector containing the observed data points.
  #-event is a status indicator (with possible values 0 and 1) for specifying
  # whether an observation is right censored (=0) or not (=1). This indicator
  # can be omitted in case of complete (uncensored) data.
  #-weight is an optional vector with the weights for the observations.
  #-dist is the assumed distribution for the data. Distributions "lognormal",
  # "gaussian", "exponential", "weibull", "sev" (=Gumbel), "frechet",
  # "lev" (=largest extreme value), "logistic" ,"loglogistic", "gamma", and
  # "beta" are implemented.
  #-shape is a vector for specifying the shape parameter(s) of distributions
  # such as the beta and gamma distribution (see Examples 2, 3, and 4 below)
  #-simplify: if TRUE then do not return a matrix containing the data points
  # (=data), standardized quantiles (=standardQuantile), and corresponding
  # probabilities.
  
  #plotting positions
  dataSorted <- data[order(data)]
  eventSorted <- event[order(data)]
  datai <- unique(dataSorted[which(eventSorted==1)])
  
  cumSurvRaw <- survfit(Surv(data, event)~ 1, weights=weight)
  cumSurv <- unique(rep(cumSurvRaw$surv, cumSurvRaw$n.event))
  cumFail <- 1-cumSurv
  lagFail <- c(0, cumFail[-length(cumFail)])
  Prob <- .5*(cumFail+lagFail)
  
  #labels for ticks along y-axis
  tick.probs <- c(.001,.005,.01,.02,.05,.1,.2,.3,.4,.5,.6,.7,.8,.9,.99,.999)
  
  #implement distributions
  if (dist=="lognormal" | dist=="gaussian") {
    yi <- qnorm(Prob) #plotting positions
    tick.pos <- qnorm(tick.probs) #positions for ticks along y-axis
    ylimr <- qnorm(range(tick.probs)) #range along y-axis
  }
  else if (dist=="exponential") {
    yi <- qexp(Prob) #plotting positions
    tick.pos <- qexp(tick.probs) #positions for ticks along y-axis
    ylimr <- qexp(range(tick.probs)) #range along y-axis
  }
  else if (dist=="weibull" | dist=="sev") {
    yi <- qsev(Prob) #plotting positions
    tick.pos <- qsev(tick.probs) #positions for ticks along y-axis
    ylimr <- qsev(range(tick.probs)) #range along y-axis
  }
  else if (dist=="frechet" | dist=="lev") {
    yi <- qlev(Prob) #plotting positions
    tick.pos <- qlev(tick.probs) #positions for ticks along y-axis
    ylimr <- qlev(range(tick.probs)) #range along y-axis
  }
  else if (dist=="loglogistic" | dist=="logistic") {
    yi <- qlogis(Prob) #plotting positions
    tick.pos <- qlogis(tick.probs) #positions for ticks along y-axis
    ylimr <- qlogis(range(tick.probs)) #range along y-axis
  }
  else if (dist=="gamma") {
    yi <- qgamma(Prob, shape=shape) #plotting positions
    tick.pos <- qgamma(tick.probs, shape=shape) #positions for ticks along y-axis
    ylimr <- qgamma(range(tick.probs), shape=shape) #range along y-axis
  }
  else if (dist=="beta") {
    yi <- qbeta(Prob, shape1=shape[1], shape2=shape[2]) #plotting positions
    tick.pos <- qbeta(tick.probs, shape1=shape[1], shape2=shape[2]) #positions for ticks along y-axis
    ylimr <- qbeta(range(tick.probs), shape1=shape[1], shape2=shape[2]) #range along y-axis
  }
  
  #determine range along x-axis
  rangeData <- range(data)
  
  #construct plot
  #distributions that require a log transform of the data scale
  if (dist=="weibull" | dist=="lognormal" | dist=="frechet" |
      dist=="loglogistic") {
    plot(0, type="n", log="x",
         xlim=c(rangeData[1], rangeData[2]),
         ylim=c(ylimr[1], ylimr[2]),
         xlab="Tiempo en horas", ylab="Proporci�n de fallas", main=paste("Distribuci�n",dist),
         pch = 20, cex = 1,axes=FALSE, frame.plot=TRUE)}
  else {
    plot(0, type="n",
         xlim=c(rangeData[1], rangeData[2]),
         ylim=c(ylimr[1], ylimr[2]),
         xlab="Tiempo en horas", ylab="Proporci�n de fallas", main=paste("Distribuci�n Exponencial"),
         axes=FALSE, frame.plot=TRUE)}
  
  axis(2, at=tick.pos, labels=tick.probs)
  axis(1)
  points(datai, yi, col="red",pch = 20, cex = 1)
  #draw raster
  abline(h = tick.pos, lty=3, col="gray")
  abline(v = axTicks(1), lty=3, col="gray")
  
  #return plotting positions
  if (!simplify) cbind(data=datai, standardQuantile=yi, probability=Prob)
  yi
  
}

library(WeibullR)

#Para realizar c)
r=13  #numero de fallas
beta0=1
#Para encontrar el valor de logverosimilitud
Totaldata=c(450, 460, 1150, 1150,1560, 1600, 1660, 1850,1850,1850,1850,1850, 2030,2030,2030,2070, 2070, 2080, 2200, 3000,3000,3000,3000
            ,3100,3200, 3450, 3750,3750, 4150,4150,4150,4150, 4300,4300,4300,4300, 4600, 4850,4850,4850,4850, 5000,5000,5000, 6100,6100,6100,6100, 6300, 6450,6450
            ,6700, 7450, 7800,7800, 8100,8100, 8200, 8500,8500,8500, 8750,8750,8750, 9400, 9900, 10100,10100,10100, 11500)

event=c(1,0,1,1,0,1,0,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0)
length(Totaldata)
length(event)
sum(event)
Ajs=Lifedata.MLE(Surv(Totaldata, event)~1, dist="weibull")
SAjs=summary(Ajs)
L1=-SAjs$min
L1 #Valor del la -logverosimilitud con los estimadores por MV de la Weibull
SAjs
sigma=SAjs$coef[2]
mu=SAjs$coef[1]
sigma
mu
eta=exp(SAjs$coef[1])
beta=1/SAjs$coef[2]
eta
beta

#Tenemos el valor de beta por lo que con esto se estimara a eta
eta0=sum(Totaldata)/r
eta0
u0=log(eta0)

#Ahora vamos a ver el valor de la logverosimilitud suponiendo a beta=1
x=c(450, 1150, 1150, 1600,2070, 2070, 2080,3100,3200, 3450, 4600, 6100,8750) #fallas exactas
s=c(460,1560, 1660, 1850,1850,1850,1850,1850, 2030,2030,2030,2200, 3000,3000,3000,3000
  , 3750,3750, 4150,4150,4150,4150, 4300,4300,4300,4300, 4850,4850,4850,4850, 5000,5000,5000,6100,6100,6100, 6300, 6450,6450
    ,6700, 7450, 7800,7800, 8100,8100, 8200, 8500,8500,8500, 8750,8750, 9400, 9900, 10100,10100,10100, 11500)
#s es vector de censuras
datos=mleframe(x, s, interval=NULL) #tipo de dato que requiere la funcion wblrloglike
datos

L2=wblrLoglike(c(1/beta0,exp(u0)), datos,dist="weibull") #c(shape,scale)
L2
lamda=2*(L1-L2)
lamda

#Datos para realizar d) y e)

#Para calcular los estimadores por MV (Weiebull)

sigma=SAjs$coef[2]
mu=SAjs$coef[1]
sigma
mu
#Estimadores
beta=1/sigma
eta=exp(mu)
beta
eta

#Cuantil t0.1

t=eta*((-log(0.9))^(1/beta))
t
SAjs$vcov

wp=log(-log(1-0.1))
log(t)
se=sqrt(SAjs$vcov[1,1]+(2*wp*abs(SAjs$vcov[1,2]))+(wp*wp)*SAjs$vcov[2,2])
t*se
#t0.1 normal
t-(qnorm(0.975)*t*se)
t+(qnorm(0.975)*t*se)

#log(t0.1) normal
log(t) #estimador
se
log(t)-(qnorm(0.975)*se)
log(t)+(qnorm(0.975)*se)
exp(log(t)-(qnorm(0.975)*se))
exp(log(t)+(qnorm(0.975)*se))


((5*(600)^(2.3))/(-log(0.05)))^(1/2.3)*(-log(0.99))^(1/2.3)
(-log(0.99))^(1/2.3)
